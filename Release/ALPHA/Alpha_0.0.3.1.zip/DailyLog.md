# Daily Log  

Day 0:  
    time     : 1hr -> (1320 - 1420)  
    Aim      : Reconfig and Create the env  
    Done     : Yes  
    NewLearn : #ifdef  
    Note     : Everything is printing in g->win but when exit the data is erased , need to check on this  
    Record   :  
            - Create the interface  
            - Connected every file  
            - Basic Layout  

Day 1:
    time     : 1hr50m -> (1310 - 1510)(200824)  
    Aim      : Init everything  
    Done     : YES
    NewLearn : do static shit in static dont go overboard make it dynamic  
    Note     :left extend ascii for now i will get to it in later  
    Record   :  
            - Init created  
            - removed Point to reduce thee complexity

Day 1.1:
    time     : 40m -> (2300 - 2340)(200824)  
    Aim      : impletemented the dash mover with pthread  
    Done     : YES
    NewLearn : pthread mutex variable existense  
    Note     : basic version of dash mover  
    Record   :  
            - dash mover pthread created  
            - idk how to combain with ball movement and idk it will work or not

Day 2:
    time     : 1hr31m -> (1605 - 1658)(1815 - 1843)(210824)  
    Aim      : Try to move the ball  
    Done     : YES
    NewLearn : mutex lock and unlock positon  
    Note     :  leaves out trail
    Record   :  

Day 2.1:
    time     : 13m (0030 - 0043)(230824)
    Aim      : remove the trail
    Done     : Yes
    Newlearn : look the mutex locking , refersh thread
    Note     : BEawre when using mutexlock
    Record   : New thread intro for controlling the refersh

Day 3:
    time     : 1hr (2133 - 2243)(250824)
    Aim      : Move ball up and down
    Done     : Yes
    Newlearn : -
    Note     : -  
    Record   : -

Day 3.1:
    time     :  (2245 - 0055)(250824)
    Aim      : Bouncing the ball around the screen
    Done     : no
    Newlearn : -
    Note     : vanishing in side an dends the program 
    Record   : -

