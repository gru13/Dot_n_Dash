# README FILE

this second try for  dash and dots (basic jordinine game) in c "first try -> [github](https://github.com/gru13/dash_n_dots)"  

Naming Culture:  
    -> direct Variable starts with caps  
    -> pointers All Small
    -> all Struct DEfined in Capitilized format
